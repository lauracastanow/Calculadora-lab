
package calculadora;
import java.util.Scanner;

public class Calculadora {

   
    public static void main(String[] args) {
        Scanner opc=new Scanner(System.in);
        Operaciones op=new Operaciones();
        double num1;
        double num2;
        double base;
        double trig;
        int poten;
        String caso;
        System.out.println("Digite la operacion que desea hacer");
        caso=opc.nextLine();
        switch(caso){
            case "+":
                System.out.println("Digite el primer termino: "); 
                num1=opc.nextDouble();
                System.out.println("Digite el segundo termino: ");
                num2=opc.nextDouble();
                System.out.println("La suma entre "+num1+ " y " +num2+ " es: " +op.suma(num1, num2));
                break;
                case "-":
                System.out.println("Digite el primer termino: "); 
                num1=opc.nextDouble();
                System.out.println("Digite el segundo termino: ");
                num2=opc.nextDouble();
                System.out.println("La resta entre "+num1+ " y " +num2+ " es: " +op.resta(num1, num2));
                break;
                case "*":
                System.out.println("Digite el primer termino: "); 
                num1=opc.nextDouble();
                System.out.println("Digite el segundo termino: ");
                num2=opc.nextDouble();
                System.out.println("La multiplicacion entre "+num1+ " y " +num2+ " es: " +op.multi(num1, num2));
                break;
                case "/":
                System.out.println("Digite el primer termino: "); 
                num1=opc.nextDouble();
                System.out.println("Digite el segundo termino: ");
                num2=opc.nextDouble();
                System.out.println("La division entre "+num1+ " y " +num2+ " es: " +op.divi(num1, num2));
                break;
                case "raiz":
                System.out.println("Digite la base: "); 
                base=opc.nextDouble();
                System.out.println("Digite el radical: ");
                poten=opc.nextInt();
                System.out.println("La raiz entre " +poten+ " de " +base+ " es: " +op.raiz(base,poten));
                break;
                case "potencia":
                System.out.println("Digite la base: "); 
                base=opc.nextDouble();
                System.out.println("Digite el exponente: ");
                poten=opc.nextInt();
                System.out.println("La potencia entre " +base+ " de " +poten+ " es: " +op.potencia(base,poten));
                break;
                case "sen":
                System.out.println("Digite el angulo "); 
                trig=opc.nextDouble();
                System.out.println("El seno de " +trig+ " es: " +op.seno(trig));
                break;
                case "cos":
                System.out.println("Digite el angulo "); 
                trig=opc.nextDouble();
                System.out.println("El coseno de " +trig+ " es: " +op.cos(trig));
                break;
                case "tan":
                System.out.println("Digite el angulo "); 
                trig=opc.nextDouble();
                System.out.println("La tangente de" +trig+ " es: " +op.tan(trig));
                break;
                
        }
        
        
    }
    
}
