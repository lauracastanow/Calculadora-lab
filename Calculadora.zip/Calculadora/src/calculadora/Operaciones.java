
package calculadora;

public class Operaciones {
 
    public double num1;
    public double num2;
    public double base;
    public double trig;
    public int poten;
    
    public static double suma(double a, double b){
        return a+b;
    }
    
    public static double resta(double num1, double num2){
        return num1-num2;
    }
    
    public static double multi(double num1, double num2){
        return num1*num2;
    }
    
    public static double divi(double num1, double num2){
        return num1/num2;
    }
    
    public static double seno(double trig){
        return Math.sin(trig);
    }
    
    public static double tan(double trig){
        return Math.tan(trig);
    }
    
    public static double cos(double trig){
        return Math.cos(trig);
    }
    
    public static double raiz(double base, int poten){
        return Math.pow(base,(1/poten));
    }
    
    public static double potencia(double base, int poten){
        return Math.pow(base,poten);
    }
}
